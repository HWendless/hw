package com.hw.cy.pojo;

public class eleshop_food {
    private  String eleShopName;
    private String eleShopAddr;
    private String eleShopPhone;
    private String eleLat;
    private String eleLon;
    private String EleShopAddr;
    private String EleShopPhone;

}
