package com.hw.cy.entity;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

public class writefile {
  public static void writer(String name,String eleid,String s,String shi,String q,String nr) throws IOException {
        FileWriter fw = new FileWriter("E:\\一点点3\\"+name+"_"+eleid+"_"+s+"_"+shi+"_"+q);
        BufferedWriter bw = new BufferedWriter(fw);
        bw.write(nr);
        bw.close();

         }
    public static void writersj(String name , String nr) throws IOException {
        FileWriter fw = new FileWriter("E:\\一点点4\\"+name);
        BufferedWriter bw = new BufferedWriter(fw);
        bw.write(nr);
        bw.close();

    }
}
